This datapack is created for Java Minecraft 1.21.1 (or 1.21)
It does NOT work in 1.21.2 or above!

Please play with graphics settings on "Fabulous" (if your computer can handle it) since vanilla shaders only display on this setting! The VFX in the end-fight will only properly glow if you do this! Nothing will break on lower settings, it's just not gonna look as good

_________________________________Setup Guide______________________________________________

To use this datapack navigate to your .minecraft folder!
(WindowsKey + R and then type %appdata%)
Open your world folder and paste the datapack file into your datapacks folder!
Go back to .minecraft, open your resourcepacks folder and then paste the resourcepack file there!
Once you're ingame, type /reload in chat and then activate the resourcepack from the menu!

____________________________________Settings___________________________________________


There are a handful of settings that you can change! Here is an overview:

/trigger difficulty set <1-3>  | Changes the overall difficulty of the datapack (so how much damage everything does, how much time you have for crafting etc.) (1=Easy, 2=Medium, 3=Hard)

/trigger dragon_difficulty set <1-3> | Changes the difficulty of the new enderdragon boss! This is controlled separately from the overall difficulty so you can change these individually. (1=Easy, 2=Medium, 3=Hard)

/trigger toggle_armor_slowdown | This lets you enable or disable the armor slowdown mechanic, in case you find it too annoying.

/trigger toggle_chest | If you are uncomfortable with guns (eventhough it is just a watergun) you can use this command to disable the chest feature entirely.

/trigger toggle_endermen | Lets you disable the enderman feature. Due to some technical minecraft limitations, this feature causes issue on servers. So I recommend keeping it enabled in singleplayer but disabling it in multiplayer.

/trigger toggle_flashbang | Lets you enable or disable flashing screen effects in the datapack. They are disabled by default and I only recommend turning them on if you are not prone to seizures.

/trigger count_features | Displays how many unique features you have encountered so far.